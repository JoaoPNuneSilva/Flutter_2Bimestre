import 'package:agro_app_aula/screens/menu.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  String logo ='https://as2.ftcdn.net/v2/jpg/03/99/60/91/1000_F_399609148_ahxqweCSjF4rjLHNpMjmTPE9DX87XRry.jpg';
  
  void navigateMenu(){
    Navigator.push(
      context, MaterialPageRoute(
        builder: (context) => const Menu()
      ),
    );
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        centerTitle: true,
        title: Text('Login'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            SizedBox(height: 40,),
            Center(
              child: CircleAvatar(
                radius: 70,
                backgroundImage: NetworkImage(logo),
              ),
            ),
            SizedBox(height: 40,),
            TextField(
              decoration: const InputDecoration(
                hintText: 'Login',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 40,),
            TextField(
              decoration: const InputDecoration(
                hintText: 'Login',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 40,),
            Row(
              children: <Widget>[
                Expanded(child: ElevatedButton(
                  onPressed: () {
                    navigateMenu();
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    minimumSize: const Size(double.infinity, 60),
                  ),
                  child: const Text(
                    'Entrar',
                    style: TextStyle(fontSize: 20),
                  ),
                ))
              ],
            )
          ],
        ),
      ),
    );
  }
}