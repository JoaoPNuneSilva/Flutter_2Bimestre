import 'package:agro_app_aula/model/produto.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class Listagem extends StatefulWidget {
  const Listagem({super.key});

  @override
  State<Listagem> createState() => _ListagemState();
}

class _ListagemState extends State<Listagem> {
  List<Produto> lisProdutos = [
    Produto(nome: 'Feijão', preco: 23),
    Produto(nome: 'Soja', preco: 23),
    Produto(nome: 'Arroz', preco: 23)
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        centerTitle: true,
        title: Text('Listagem'),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount:lisProdutos.length ,
              itemBuilder: (context, index){
              return Text(lisProdutos[index].nome);
              }),
          )
        ]
      ),
    );
  }
}