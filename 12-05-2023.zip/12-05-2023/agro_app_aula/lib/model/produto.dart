class Produto {
  String nome;
  double preco;

  Produto({
    this.nome = '',
    this.preco = 0
  });
}