package com.example.agro_app_aula

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
